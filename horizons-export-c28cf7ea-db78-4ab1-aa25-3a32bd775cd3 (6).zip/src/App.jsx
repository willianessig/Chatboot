
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import ChatPage from '@/pages/ChatPage';
import AdminLayout from '@/components/AdminLayout';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import UserManagement from '@/pages/admin/UserManagement';
import WebhookSettings from '@/pages/admin/WebhookSettings';
import AppearanceSettings from '@/pages/admin/AppearanceSettings';
import LoginPage from '@/pages/LoginPage';
import ForgotPasswordPage from '@/pages/ForgotPasswordPage';
import ProtectedRoute from '@/components/ProtectedRoute';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { SettingsProvider, useSettings } from '@/contexts/SettingsContext';

const AppContent = () => {
  useSettings();
  const { loading } = useAuth();

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-hh-dark-green">
        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-hh-vibrant-green"></div>
      </div>
    );
  }

  return (
    <>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        
        <Route path="/chat" element={<ProtectedRoute><ChatPage /></ProtectedRoute>} />

        <Route 
          path="/admin" 
          element={
            <ProtectedRoute adminOnly={true}>
              <AdminLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Navigate to="users" replace />} />
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="users" element={<UserManagement />} />
          <Route path="webhooks" element={<WebhookSettings />} />
          <Route path="appearance" element={<AppearanceSettings />} />
        </Route>
      </Routes>
      <Toaster />
    </>
  );
};

const App = () => (
  <>
    <Helmet>
      <title>Assistente IA Empresarial</title>
      <meta name="description" content="Sistema de chat com IA para suporte empresarial interno" />
    </Helmet>
    <Router>
      <SettingsProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </SettingsProvider>
    </Router>
  </>
);

export default App;
  