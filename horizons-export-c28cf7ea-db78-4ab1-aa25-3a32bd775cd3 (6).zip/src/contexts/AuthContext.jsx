
import React, { createContext, useState, useContext, useEffect } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initialize users if not present
    if (!localStorage.getItem('users')) {
      const defaultUsers = [{
        id: 1,
        username: 'admin',
        email: 'admin@brasilata.com.br',
        password: 'admin', // In a real app, this would be hashed
        isAdmin: true,
        createdAt: new Date().toISOString()
      }, {
        id: 2,
        username: 'user',
        email: 'user@brasilata.com.br',
        password: 'user', // In a real app, this would be hashed
        isAdmin: false,
        createdAt: new Date().toISOString()
      }];
      localStorage.setItem('users', JSON.stringify(defaultUsers));
    }

    // Check for logged-in user
    const loggedInUser = localStorage.getItem('loggedInUser');
    if (loggedInUser) {
      setUser(JSON.parse(loggedInUser));
    }
    setLoading(false);
  }, []);

  const login = (username, password) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const foundUser = users.find(u => u.username === username && u.password === password);
    
    if (foundUser) {
      const userToStore = { id: foundUser.id, username: foundUser.username, isAdmin: foundUser.isAdmin, email: foundUser.email };
      setUser(userToStore);
      localStorage.setItem('loggedInUser', JSON.stringify(userToStore));
      return userToStore;
    }
    return null;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('loggedInUser');
  };

  const value = { user, loading, login, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
  