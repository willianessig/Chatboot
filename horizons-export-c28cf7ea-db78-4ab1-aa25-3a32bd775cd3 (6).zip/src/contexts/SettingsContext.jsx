
    import React, { createContext, useState, useContext, useEffect } from 'react';

    const SettingsContext = createContext(null);

    const initialSettings = {
      colorDarkGreen: '#264e3e',
      colorLightBrown: '#c7b8a9',
      colorVibrantGreen: '#7dba51',
      colorMutedGreen: '#658d76',
      colorGrayGreen: '#899e9c',
      colorInputText: '#ffffff',
      colorLoginInputText: '#000000', // Nova cor para o texto do input de login
      timeout: 15000,
    };

    export const SettingsProvider = ({ children }) => {
      const [settings, setSettings] = useState(() => {
        const savedSettings = localStorage.getItem('appSettings');
        return savedSettings ? JSON.parse(savedSettings) : initialSettings;
      });
      const [logo, setLogo] = useState(() => localStorage.getItem('appLogo') || null);

      useEffect(() => {
        const root = document.documentElement;
        root.style.setProperty('--hh-dark-green', settings.colorDarkGreen);
        root.style.setProperty('--hh-light-brown', settings.colorLightBrown);
        root.style.setProperty('--hh-vibrant-green', settings.colorVibrantGreen);
        root.style.setProperty('--hh-muted-green', settings.colorMutedGreen);
        root.style.setProperty('--hh-gray-green', settings.colorGrayGreen);
        root.style.setProperty('--hh-input-text', settings.colorInputText);
        root.style.setProperty('--hh-login-input-text', settings.colorLoginInputText);
      }, [settings]);

      const saveSettings = (newSettings) => {
        const updatedSettings = { ...settings, ...newSettings };
        setSettings(updatedSettings);
        localStorage.setItem('appSettings', JSON.stringify(updatedSettings));
      };

      const saveLogo = (newLogo) => {
        setLogo(newLogo);
        localStorage.setItem('appLogo', newLogo);
      };

      const value = { settings, saveSettings, logo, saveLogo };

      return (
        <SettingsContext.Provider value={value}>
          {children}
        </SettingsContext.Provider>
      );
    };

    export const useSettings = () => {
      return useContext(SettingsContext);
    };
  