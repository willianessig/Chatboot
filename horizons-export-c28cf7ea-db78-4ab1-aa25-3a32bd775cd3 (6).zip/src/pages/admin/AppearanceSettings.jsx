import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Palette, Save, Upload, Image as ImageIcon, Type } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useSettings } from '@/contexts/SettingsContext';

const AppearanceSettings = () => {
  const { settings, saveSettings, logo, saveLogo } = useSettings();
  const [localSettings, setLocalSettings] = useState(settings);
  const [localLogo, setLocalLogo] = useState(logo);
  const { toast } = useToast();
  const fileInputRef = useRef(null);

  const handleColorChange = (key, value) => {
    setLocalSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleLogoChange = (event) => {
    const file = event.target.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setLocalLogo(e.target.result);
      };
      reader.readAsDataURL(file);
    } else {
      toast({ title: "Arquivo inválido", description: "Por favor, selecione um arquivo de imagem.", variant: "destructive" });
    }
  };

  const handleSave = () => {
    saveSettings(localSettings);
    if (localLogo) {
      saveLogo(localLogo);
    }
    toast({ title: "Aparência salva!", description: "As novas configurações de aparência foram aplicadas." });
  };

  const ColorInput = ({ label, colorKey, icon: Icon }) => (
    <div>
      <label className="text-sm text-gray-300 flex items-center mb-1">
        {Icon && <Icon className="w-4 h-4 mr-2" />}
        {label}
      </label>
      <div className="flex items-center gap-2 p-2 bg-hh-dark-green/20 border border-hh-light-brown/20 rounded-lg">
        <input type="color" value={localSettings[colorKey]} onChange={(e) => handleColorChange(colorKey, e.target.value)} className="w-8 h-8 p-0 border-none rounded cursor-pointer bg-transparent" />
        <input type="text" value={localSettings[colorKey]} onChange={(e) => handleColorChange(colorKey, e.target.value)} className="w-full bg-transparent text-white font-mono" />
      </div>
    </div>
  );

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6 flex items-center"><Palette className="mr-3" />Configurações de Aparência</h1>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-hh-dark-green/50 p-6 rounded-lg mb-6">
        <h2 className="text-xl font-semibold mb-4">Logotipo</h2>
        <div className="flex items-center gap-6">
          <div className="w-24 h-24 bg-hh-dark-green/20 border-2 border-dashed border-hh-light-brown/30 rounded-lg flex items-center justify-center">
            {localLogo ? <img src={localLogo} alt="Preview" className="max-w-full max-h-full object-contain" /> : <ImageIcon className="w-8 h-8 text-gray-500" />}
          </div>
          <div>
            <input type="file" ref={fileInputRef} onChange={handleLogoChange} accept="image/*" className="hidden" />
            <Button onClick={() => fileInputRef.current.click()} className="bg-hh-muted-green hover:bg-hh-muted-green/80"><Upload className="w-4 h-4 mr-2" />Carregar Logo</Button>
            <p className="text-xs text-gray-400 mt-2">Use uma imagem com fundo transparente (PNG) para melhores resultados.</p>
          </div>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-hh-dark-green/50 p-6 rounded-lg">
        <h2 className="text-xl font-semibold mb-4">Paleta de Cores</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <ColorInput label="Fundo (Verde Escuro)" colorKey="colorDarkGreen" />
          <ColorInput label="Detalhes (Marrom Claro)" colorKey="colorLightBrown" />
          <ColorInput label="Destaque (Verde Vibrante)" colorKey="colorVibrantGreen" />
          <ColorInput label="Secundário (Verde Suave)" colorKey="colorMutedGreen" />
          <ColorInput label="UI (Verde Acinzentado)" colorKey="colorGrayGreen" />
          <ColorInput label="Texto do Input (Chat)" colorKey="colorInputText" icon={Type} />
        </div>
      </motion.div>

      <div className="mt-8">
        <Button onClick={handleSave} size="lg" className="bg-hh-vibrant-green hover:bg-hh-vibrant-green/80"><Save className="w-5 h-5 mr-2" />Salvar Todas as Alterações</Button>
      </div>
    </div>
  );
};

export default AppearanceSettings;