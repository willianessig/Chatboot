import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit2, Trash2, Save, X, Globe, AlertTriangle, CheckCircle2, Settings, Timer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useSettings } from '@/contexts/SettingsContext';

const WebhookSettings = () => {
  const [webhooks, setWebhooks] = useState([]);
  const { settings, saveSettings } = useSettings();
  const [isEditing, setIsEditing] = useState(null);
  const [editForm, setEditForm] = useState({ name: '', url: '', responseKey: 'response' });
  const [showAddForm, setShowAddForm] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const savedWebhooks = JSON.parse(localStorage.getItem('webhooks') || '[]');
    setWebhooks(savedWebhooks);
  }, []);

  const saveWebhooksToStorage = (newWebhooks) => {
    localStorage.setItem('webhooks', JSON.stringify(newWebhooks));
    setWebhooks(newWebhooks);
  };

  const handleSaveSettings = () => {
    saveSettings({ timeout: settings.timeout });
    toast({ title: "Configurações salvas", description: "As novas configurações de comunicação foram salvas." });
  };

  const handleAdd = () => {
    if (!editForm.name || !editForm.url) {
      toast({ title: "Campos obrigatórios", variant: "destructive" });
      return;
    }
    const newWebhook = { id: Date.now(), ...editForm, responseKey: editForm.responseKey || 'response' };
    saveWebhooksToStorage([...webhooks, newWebhook]);
    setEditForm({ name: '', url: '', responseKey: 'response' });
    setShowAddForm(false);
    toast({ title: "Webhook adicionado" });
  };

  const handleEdit = (webhook) => {
    setIsEditing(webhook.id);
    setEditForm({ name: webhook.name, url: webhook.url, responseKey: webhook.responseKey || 'response' });
  };

  const handleSave = () => {
    const updatedWebhooks = webhooks.map(w => w.id === isEditing ? { ...w, ...editForm, responseKey: editForm.responseKey || 'response' } : w);
    saveWebhooksToStorage(updatedWebhooks);
    setIsEditing(null);
    toast({ title: "Webhook atualizado" });
  };

  const handleDelete = (id) => {
    saveWebhooksToStorage(webhooks.filter(w => w.id !== id));
    toast({ title: "Webhook removido", variant: "destructive" });
  };

  const testWebhook = async (url) => {
    toast({ title: "Testando Webhook..." });
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), settings.timeout);
      const response = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: 'Teste' }), signal: controller.signal });
      clearTimeout(timeoutId);
      if (!response.ok) throw new Error(`Erro: ${response.status}`);
      const data = await response.json();
      toast({ title: "Webhook OK!", description: `Resposta: ${JSON.stringify(data).substring(0, 100)}...`, action: <CheckCircle2 className="text-green-500" /> });
    } catch (error) {
      toast({ title: "Falha no teste", description: error.message, variant: "destructive", action: <AlertTriangle className="text-red-500" /> });
    }
  };

  const renderForm = (handler, buttonText) => (
    <div className="space-y-4">
      <input type="text" placeholder="Nome do Webhook" value={editForm.name} onChange={e => setEditForm({...editForm, name: e.target.value})} className="w-full bg-hh-dark-green/10 border border-hh-light-brown/20 rounded-lg p-2 text-white" />
      <input type="url" placeholder="URL do Webhook" value={editForm.url} onChange={e => setEditForm({...editForm, url: e.target.value})} className="w-full bg-hh-dark-green/10 border border-hh-light-brown/20 rounded-lg p-2 text-white" />
      <input type="text" placeholder="Chave de Resposta (ex: response)" value={editForm.responseKey} onChange={e => setEditForm({...editForm, responseKey: e.target.value})} className="w-full bg-hh-dark-green/10 border border-hh-light-brown/20 rounded-lg p-2 text-white" />
      <div className="flex space-x-2">
        <Button onClick={handler} className="bg-hh-vibrant-green hover:bg-hh-vibrant-green/80"><Save className="w-4 h-4 mr-2" />{buttonText}</Button>
        <Button variant="ghost" onClick={() => { setIsEditing(null); setShowAddForm(false); }}><X className="w-4 h-4 mr-2" />Cancelar</Button>
      </div>
    </div>
  );

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Configurações de Webhook</h1>
      
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-hh-dark-green/50 p-6 rounded-lg mb-6">
        <h2 className="text-xl font-semibold mb-4 flex items-center"><Settings className="mr-2" />Configurações Gerais</h2>
        <div className="flex items-end gap-4">
          <div className="flex-grow">
            <label htmlFor="timeout" className="text-sm text-gray-300 mb-1 block flex items-center"><Timer className="w-4 h-4 mr-2" />Timeout da Requisição (ms)</label>
            <input id="timeout" type="number" value={settings.timeout} onChange={(e) => saveSettings({ timeout: parseInt(e.target.value, 10) })} className="w-full bg-hh-dark-green/10 border border-hh-light-brown/20 rounded-lg p-2 text-white" />
          </div>
          <Button onClick={handleSaveSettings} className="bg-hh-vibrant-green hover:bg-hh-vibrant-green/80"><Save className="w-4 h-4 mr-2" />Salvar</Button>
        </div>
      </motion.div>

      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Webhooks</h2>
        <Button onClick={() => { setShowAddForm(true); setIsEditing(null); setEditForm({ name: '', url: '', responseKey: 'response' }); }} className="bg-hh-vibrant-green hover:bg-hh-vibrant-green/80"><Plus className="w-4 h-4 mr-2" />Adicionar Webhook</Button>
      </div>

      {showAddForm && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="bg-hh-dark-green/50 p-4 rounded-lg mb-6">
          <h3 className="text-xl font-semibold mb-4">Novo Webhook</h3>
          {renderForm(handleAdd, "Adicionar")}
        </motion.div>
      )}

      <div className="space-y-4">
        {webhooks.map(webhook => (
          <motion.div key={webhook.id} layout className="bg-hh-dark-green/50 p-4 rounded-lg">
            {isEditing === webhook.id ? (
              renderForm(handleSave, "Salvar")
            ) : (
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold">{webhook.name}</p>
                  <p className="text-sm text-gray-400 font-mono">{webhook.url}</p>
                </div>
                <div className="flex space-x-1">
                  <Button size="icon" variant="ghost" onClick={() => testWebhook(webhook.url)}><Globe className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => handleEdit(webhook)}><Edit2 className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" className="text-red-400 hover:text-red-300" onClick={() => handleDelete(webhook.id)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </div>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default WebhookSettings;