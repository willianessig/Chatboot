
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit2, Trash2, Save, X, User, Shield, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const UserManagement = () => {
  const [users, setUsers] = useState([]);
  const [isEditing, setIsEditing] = useState(null);
  const [editForm, setEditForm] = useState({ id: null, username: '', email: '', password: '', isAdmin: false });
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  const loadUsers = () => {
    const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
    setUsers(storedUsers);
  };
  
  useEffect(() => {
    loadUsers();
  }, []);

  const handleAdd = () => {
    if (!editForm.username || !editForm.email || !editForm.password) {
      toast({ title: "Campos obrigatórios", description: "Todos os campos são obrigatórios.", variant: "destructive" });
      return;
    }
    const newUser = {
      id: Date.now(),
      ...editForm,
      createdAt: new Date().toISOString()
    };
    const updatedUsers = [...users, newUser];
    localStorage.setItem('users', JSON.stringify(updatedUsers));
    setUsers(updatedUsers);
    toast({ title: "Usuário adicionado", description: "Novo usuário criado com sucesso!" });
    setEditForm({ id: null, username: '', email: '', password: '', isAdmin: false });
    setShowAddForm(false);
  };

  const handleEdit = (user) => {
    setIsEditing(user.id);
    setEditForm({ ...user, password: '' });
  };

  const handleSave = () => {
    const updatedUsers = users.map(u => {
      if (u.id === isEditing) {
        return {
          ...u,
          username: editForm.username,
          email: editForm.email,
          isAdmin: editForm.isAdmin,
          // Only update password if a new one is provided
          password: editForm.password ? editForm.password : u.password
        };
      }
      return u;
    });
    localStorage.setItem('users', JSON.stringify(updatedUsers));
    setUsers(updatedUsers);
    toast({ title: "Usuário atualizado", description: "Alterações salvas com sucesso!" });
    setIsEditing(null);
  };

  const handleDelete = (id) => {
    const updatedUsers = users.filter(u => u.id !== id);
    localStorage.setItem('users', JSON.stringify(updatedUsers));
    setUsers(updatedUsers);
    toast({ title: "Usuário removido", description: "Usuário removido com sucesso." });
  };

  const filteredUsers = users.filter(user => 
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderForm = (handler, buttonText) => (
    <div className="space-y-4">
      <input type="text" placeholder="Nome de usuário" value={editForm.username} onChange={e => setEditForm({...editForm, username: e.target.value})} className="w-full bg-hh-dark-green/10 border border-hh-light-brown/20 rounded-lg p-2 text-white" />
      <input type="email" placeholder="E-mail" value={editForm.email} onChange={e => setEditForm({...editForm, email: e.target.value})} className="w-full bg-hh-dark-green/10 border border-hh-light-brown/20 rounded-lg p-2 text-white" />
      <input type="password" placeholder={isEditing ? "Nova senha (deixe em branco para não alterar)" : "Senha"} value={editForm.password} onChange={e => setEditForm({...editForm, password: e.target.value})} className="w-full bg-hh-dark-green/10 border border-hh-light-brown/20 rounded-lg p-2 text-white" />
      <div className="flex items-center space-x-2">
        <input type="checkbox" id="isAdmin" checked={editForm.isAdmin} onChange={e => setEditForm({...editForm, isAdmin: e.target.checked})} />
        <label htmlFor="isAdmin" className="text-sm">É Administrador?</label>
      </div>
      <div className="flex space-x-2">
        <Button onClick={handler} className="bg-hh-vibrant-green hover:bg-hh-vibrant-green/80"><Save className="w-4 h-4 mr-2" />{buttonText}</Button>
        <Button variant="ghost" onClick={() => { setIsEditing(null); setShowAddForm(false); }}><X className="w-4 h-4 mr-2" />Cancelar</Button>
      </div>
    </div>
  );

  return (
    <div>
      <div className="flex justify-between items-center mb-6 gap-4 flex-wrap">
        <h1 className="text-3xl font-bold">Gerenciamento de Usuários</h1>
        <div className="flex gap-2 items-center">
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input type="text" placeholder="Buscar..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full max-w-xs bg-hh-dark-green/10 border border-hh-light-brown/20 rounded-lg pl-10 p-2 text-white" />
            </div>
            <Button onClick={() => { setShowAddForm(true); setIsEditing(null); setEditForm({ id: null, username: '', email: '', password: '', isAdmin: false }); }} className="bg-hh-vibrant-green hover:bg-hh-vibrant-green/80 shrink-0"><Plus className="w-4 h-4 mr-2" />Adicionar Usuário</Button>
        </div>
      </div>

      {showAddForm && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="bg-hh-dark-green/50 p-4 rounded-lg mb-6">
          <h2 className="text-xl font-semibold mb-4">Novo Usuário</h2>
          {renderForm(handleAdd, "Criar Usuário")}
        </motion.div>
      )}

      <div className="space-y-4">
        {filteredUsers.map(user => (
          <motion.div key={user.id} layout className="bg-hh-dark-green/50 p-4 rounded-lg">
            {isEditing === user.id ? (
              renderForm(handleSave, "Salvar Alterações")
            ) : (
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded-full ${user.isAdmin ? 'bg-hh-vibrant-green' : 'bg-hh-muted-green'}`}>
                    {user.isAdmin ? <Shield className="w-5 h-5" /> : <User className="w-5 h-5" />}
                  </div>
                  <div>
                    <p className="font-semibold">{user.username}</p>
                    <p className="text-sm text-gray-400">{user.email}</p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button size="icon" variant="ghost" onClick={() => handleEdit(user)}><Edit2 className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" className="text-red-400 hover:text-red-300" onClick={() => handleDelete(user.id)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </div>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default UserManagement;
  