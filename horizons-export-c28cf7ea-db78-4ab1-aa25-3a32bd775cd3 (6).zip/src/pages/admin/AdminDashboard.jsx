
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Globe, Palette, MessageSquare } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  const { user } = useAuth();
  const [userCount, setUserCount] = useState(0);
  const [webhookCount, setWebhookCount] = useState(0);

  useEffect(() => {
    const fetchStats = () => {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      setUserCount(users.length);

      const webhooks = JSON.parse(localStorage.getItem('webhooks') || '[]');
      setWebhookCount(webhooks.length);
    };

    fetchStats();
  }, []);

  const StatCard = ({ icon: Icon, title, value, color, to }) => (
    <Link to={to}>
      <motion.div
        whileHover={{ y: -5, boxShadow: '0 10px 20px rgba(0,0,0,0.2)' }}
        className={`bg-hh-dark-green/50 backdrop-blur-lg p-6 rounded-2xl border border-hh-light-brown/20 flex items-center space-x-4`}
      >
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div>
          <p className="text-sm text-gray-300">{title}</p>
          <p className="text-2xl font-bold">{value}</p>
        </div>
      </motion.div>
    </Link>
  );

  return (
    <div>
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold text-white">Bem-vindo, {user?.username}!</h1>
        <p className="text-gray-400 mt-1">Este é o seu painel de controle central.</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <StatCard icon={Users} title="Usuários Registrados" value={userCount} color="bg-blue-500" to="/admin/users" />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <StatCard icon={Globe} title="Webhooks Configurados" value={webhookCount} color="bg-hh-vibrant-green" to="/admin/webhooks" />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <StatCard icon={Palette} title="Aparência" value="Customizável" color="bg-purple-500" to="/admin/appearance" />
        </motion.div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ delay: 0.4 }}
        className="mt-8 bg-hh-dark-green/50 backdrop-blur-lg p-6 rounded-2xl border border-hh-light-brown/20"
      >
        <h2 className="text-xl font-semibold mb-4">Acesso Rápido</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Link to="/admin/users" className="text-center p-4 bg-hh-muted-green/20 rounded-lg hover:bg-hh-muted-green/40 transition-colors">
            <Users className="mx-auto w-8 h-8 mb-2 text-hh-light-brown" />
            <span className="text-sm">Gerenciar Usuários</span>
          </Link>
          <Link to="/admin/webhooks" className="text-center p-4 bg-hh-muted-green/20 rounded-lg hover:bg-hh-muted-green/40 transition-colors">
            <Globe className="mx-auto w-8 h-8 mb-2 text-hh-light-brown" />
            <span className="text-sm">Configurar Webhooks</span>
          </Link>
          <Link to="/admin/appearance" className="text-center p-4 bg-hh-muted-green/20 rounded-lg hover:bg-hh-muted-green/40 transition-colors">
            <Palette className="mx-auto w-8 h-8 mb-2 text-hh-light-brown" />
            <span className="text-sm">Editar Aparência</span>
          </Link>
          <Link to="/chat" className="text-center p-4 bg-hh-muted-green/20 rounded-lg hover:bg-hh-muted-green/40 transition-colors">
            <MessageSquare className="mx-auto w-8 h-8 mb-2 text-hh-light-brown" />
            <span className="text-sm">Ir para o Chat</span>
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

export default AdminDashboard;
  