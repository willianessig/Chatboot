
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Lock, Mail, Eye, EyeOff, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useSettings } from '@/contexts/SettingsContext';

const LoginPage = () => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const { login, loading, user } = useAuth();
  const { settings, logo } = useSettings();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      if (user.isAdmin) {
        navigate('/admin', { replace: true });
      } else {
        navigate('/chat', { replace: true });
      }
    }
  }, [user, navigate]);

  const handleLogin = (e) => {
    e.preventDefault();
    const loggedInUser = login(credentials.username, credentials.password);
    if (loggedInUser) {
      toast({ title: "Login bem-sucedido!", description: "Redirecionando..." });
      if (loggedInUser.isAdmin) {
        navigate('/admin', { replace: true });
      } else {
        navigate('/chat', { replace: true });
      }
    } else {
      toast({
        variant: "destructive",
        title: "Falha no login",
        description: "Nome de usuário ou senha incorretos.",
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-hh-dark-green">
      <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-full max-w-md">
        <div className="bg-hh-dark-green/50 backdrop-blur-lg rounded-3xl p-8 border border-hh-light-brown/20 shadow-2xl">
          <div className="text-center mb-8">
            <motion.div initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }} className="mx-auto mb-4">
              {logo ? (
                <img src={logo} alt="Logo" className="h-16 w-auto mx-auto" />
              ) : (
                <div className="w-16 h-16 bg-gradient-to-r from-hh-muted-green to-hh-vibrant-green rounded-2xl flex items-center justify-center mx-auto">
                  <Shield className="w-8 h-8 text-white" />
                </div>
              )}
            </motion.div>
            <h1 className="text-2xl font-bold text-white mb-2">Assistente IA</h1>
            <p className="text-gray-300">Acesse com suas credenciais</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Nome de Usuário</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input 
                  type="text" 
                  value={credentials.username} 
                  onChange={(e) => setCredentials({ ...credentials, username: e.target.value })} 
                  className="w-full bg-hh-dark-green/10 border border-hh-light-brown/20 rounded-xl pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-hh-vibrant-green" 
                  placeholder="Digite seu nome de usuário" 
                  style={{ color: settings.colorLoginInputText }}
                  required />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Senha</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input 
                  type={showPassword ? 'text' : 'password'} 
                  value={credentials.password} 
                  onChange={(e) => setCredentials({ ...credentials, password: e.target.value })} 
                  className="w-full bg-hh-dark-green/10 border border-hh-light-brown/20 rounded-xl pl-10 pr-12 py-3 focus:outline-none focus:ring-2 focus:ring-hh-vibrant-green" 
                  placeholder="Digite sua senha" 
                  style={{ color: settings.colorLoginInputText }}
                  required />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white">{showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}</button>
              </div>
            </div>
            <div className="text-right">
              <Link to="/forgot-password" className="text-sm text-hh-light-brown hover:underline">Esqueceu a senha?</Link>
            </div>
            <div>
              <Button type="submit" disabled={loading} className="w-full bg-hh-vibrant-green hover:bg-hh-vibrant-green/80 text-white py-3 rounded-xl font-semibold">
                {loading ? 'Entrando...' : 'Entrar'}
              </Button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;
  