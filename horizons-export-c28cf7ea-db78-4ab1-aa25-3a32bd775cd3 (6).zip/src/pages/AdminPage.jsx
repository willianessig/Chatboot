import React from 'react';
import { Navigate } from 'react-router-dom';

const AdminPage = () => {
  // This page is now a layout, so we redirect to the dashboard.
  return <Navigate to="/admin/dashboard" replace />;
};

export default AdminPage;