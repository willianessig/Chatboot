
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { useSettings } from '@/contexts/SettingsContext';

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { logo } = useSettings();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    // This is a placeholder. In a real app, this would trigger an email.
    setTimeout(() => {
      toast({
        title: "Funcionalidade não implementada",
        description: "A recuperação de senha não está disponível no modo offline.",
      });
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-hh-dark-green">
      <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-full max-w-md">
        <div className="bg-hh-dark-green/50 backdrop-blur-lg rounded-3xl p-8 border border-hh-light-brown/20 shadow-2xl">
          <div className="text-center mb-8">
            <motion.div initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }} className="mx-auto mb-4">
              {logo ? (
                <img src={logo} alt="Logo" className="h-16 w-auto mx-auto" />
              ) : (
                <div className="w-16 h-16 bg-gradient-to-r from-hh-muted-green to-hh-vibrant-green rounded-2xl flex items-center justify-center mx-auto">
                  <HelpCircle className="w-8 h-8 text-white" />
                </div>
              )}
            </motion.div>
            <h1 className="text-2xl font-bold text-white mb-2">Recuperar Senha</h1>
            <p className="text-gray-300">Insira seu e-mail para redefinir a senha.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">E-mail</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-hh-dark-green/10 border border-hh-light-brown/20 rounded-xl pl-10 pr-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-hh-vibrant-green" placeholder="seu.email@empresa.com" required />
              </div>
            </div>
            <div>
              <Button type="submit" disabled={loading} className="w-full bg-hh-vibrant-green hover:bg-hh-vibrant-green/80 text-white py-3 rounded-xl font-semibold">
                {loading ? 'Enviando...' : 'Enviar Link de Recuperação'}
              </Button>
            </div>
          </form>
          <div className="mt-6 text-center">
            <button onClick={() => navigate('/login')} className="text-gray-400 hover:text-white text-sm">← Voltar para o Login</button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ForgotPasswordPage;
  