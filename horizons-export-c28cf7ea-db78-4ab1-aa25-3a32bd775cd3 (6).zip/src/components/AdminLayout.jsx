import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useSettings } from '@/contexts/SettingsContext';
import { Button } from '@/components/ui/button';
import { LayoutDashboard, Users, Globe, Palette, LogOut, Menu, X, MessageSquare } from 'lucide-react';

const AdminLayout = () => {
  const { logout, user } = useAuth();
  const { logo } = useSettings();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { to: '/admin', icon: LayoutDashboard, label: 'Dashboard' },
    { to: '/admin/users', icon: Users, label: 'Usuários' },
    { to: '/admin/webhooks', icon: Globe, label: 'Webhooks' },
    { to: '/admin/appearance', icon: Palette, label: 'Aparência' },
  ];

  const NavItem = ({ to, icon: Icon, label }) => (
    <NavLink
      to={to}
      end={to === '/admin'}
      className={({ isActive }) =>
        `flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
          isActive
            ? 'bg-hh-vibrant-green text-white'
            : 'text-gray-300 hover:bg-hh-muted-green/50 hover:text-white'
        }`
      }
      onClick={() => setIsSidebarOpen(false)}
    >
      <Icon className="w-5 h-5 mr-3" />
      <span>{label}</span>
    </NavLink>
  );

  return (
    <div className="min-h-screen flex bg-hh-dark-green text-white">
      {/* Mobile Sidebar Toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 lg:hidden"
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
      >
        {isSidebarOpen ? <X /> : <Menu />}
      </Button>

      {/* Sidebar */}
      <aside className={`fixed lg:relative inset-y-0 left-0 z-40 w-64 bg-hh-dark-green/80 backdrop-blur-xl border-r border-hh-light-brown/10 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300 ease-in-out`}>
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-center h-20 border-b border-hh-light-brown/10">
            {logo ? (
              <img src={logo} alt="Logo" className="h-10 w-auto" />
            ) : (
              <h1 className="text-xl font-bold text-white">Admin</h1>
            )}
          </div>
          <nav className="flex-1 p-4 space-y-2">
            {navItems.map(item => <NavItem key={item.to} {...item} />)}
          </nav>
          <div className="p-4 border-t border-hh-light-brown/10">
            <div className="text-center mb-4">
              <p className="text-sm font-semibold">{user?.username}</p>
              <p className="text-xs text-gray-400">{user?.isAdmin ? 'Administrador' : 'Usuário'}</p>
            </div>
            <Button variant="ghost" className="w-full justify-start text-gray-300 hover:bg-hh-muted-green/50" onClick={() => navigate('/chat')}>
              <MessageSquare className="w-5 h-5 mr-3" /> Voltar ao Chat
            </Button>
            <Button variant="ghost" className="w-full justify-start text-red-400 hover:bg-red-500/20 hover:text-red-300 mt-2" onClick={handleLogout}>
              <LogOut className="w-5 h-5 mr-3" /> Sair
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 lg:ml-0 transition-all duration-300 ease-in-out">
        <div className="p-6 lg:p-8 mt-16 lg:mt-0">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default AdminLayout;